
package finalproject2017.storeorganizer;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.ComboBoxListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;



/**
 *
 * @author carolinebloch
 */
public class FinalProject2017StoreOrganizer extends Application {

    private final Node target = new ImageView( new Image("images/target.png"));
    private final Node starbucks = new ImageView( new Image("images/Starbucks.png"));
    private final Node walmart = new ImageView( new Image("images/Walmart.jpeg"));
    private final Node cvs = new ImageView( new Image("images/cvs.png"));
    private final Node gap = new ImageView( new Image("images/Gap.png"));
    private final Node sonic = new ImageView( new Image("images/Sonic.png"));
    private final Node forever21 = new ImageView( new Image("images/Forever21.png"));
    private final Node employees = new ImageView( new Image("images/Employees.png"));

    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {

        ((ImageView)target).setFitWidth(15);
        ((ImageView)target).setFitHeight(15);
        ((ImageView)starbucks).setFitWidth(15);
        ((ImageView)starbucks).setFitHeight(15);
        ((ImageView)walmart).setFitWidth(15);
        ((ImageView)walmart).setFitHeight(15);
        ((ImageView)cvs).setFitWidth(15);
        ((ImageView)cvs).setFitHeight(15);
        ((ImageView)gap).setFitWidth(15);
        ((ImageView)gap).setFitHeight(15);
        ((ImageView)sonic).setFitWidth(15);
        ((ImageView)sonic).setFitHeight(15);
        ((ImageView)forever21).setFitWidth(15);
        ((ImageView)forever21).setFitHeight(15);
        ((ImageView)employees).setFitWidth(15);
        ((ImageView)employees).setFitHeight(15);
        
        File file = new File ("NamesAndStores.txt");
                
        Map <String, String> organizer = new HashMap <String, String>();
        
        ArrayList <String> storeList = new ArrayList <String> ();
        ArrayList <String> nameList = new ArrayList <String> (); 
        
        TreeItem<String> rootItem = new TreeItem<>("Employee List", employees);
        TreeItem<String> item = new TreeItem<>();
        TreeView<String> tree = new TreeView<>();
        
        Scanner scan = new Scanner (file);
        
        VBox root = new VBox();
        
        while (scan.hasNext())
        {
            String name = scan.next() + " " + scan.next();
            String store = scan.next();
            if (!organizer.containsValue(store)) 
                storeList.add(store);
            organizer.put(name, store);
            nameList.add(name);
        }
        
        scan.close();
       

       for (int x = 0; x<storeList.size(); x++)
        {
            if (storeList.get(x).equals("Target"))
                item = new TreeItem<>(storeList.get(x),target);
            else if (storeList.get(x).equals("CVS"))
                item = new TreeItem<>(storeList.get(x),cvs);
            else if (storeList.get(x).equals("Starbucks"))
                item = new TreeItem<>(storeList.get(x),starbucks);
            else if (storeList.get(x).equals("Forever21"))
                item = new TreeItem<>(storeList.get(x),forever21);
            else if (storeList.get(x).equals("Gap"))
                item = new TreeItem<>(storeList.get(x),gap);
            else if (storeList.get(x).equals("Walmart"))
                item = new TreeItem<>(storeList.get(x),walmart);
            else if (storeList.get(x).equals("Sonic"))
                item = new TreeItem<>(storeList.get(x),sonic);
            else 
                item = new TreeItem(storeList.get(x));
    
            for (int y = 0; y < nameList.size(); y++)
            {
                if (organizer.get(nameList.get(y)).equals(storeList.get(x)))
                    item.getChildren().addAll(new TreeItem<>(nameList.get(y)));
            }
              
            rootItem.getChildren().addAll(item);
        }
       
            tree = new TreeView<>(rootItem);
            root.getChildren().add(tree);

        Scene scene = new Scene(root);
        
        primaryStage.setTitle("Employee Organizer");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
